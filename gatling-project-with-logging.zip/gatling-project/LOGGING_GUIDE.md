# 📝 Logging Guide

## Overview
This Gatling framework includes a custom logging system that creates timestamped folders and detailed log files for each test run.

## Folder Structure

Every test run creates a unique timestamped folder:

```
project-root/
└── test-logs/
    ├── 2026-01-27_15-30-45/       ← Test Run 1
    │   └── test-execution.log
    ├── 2026-01-27_16-45-20/       ← Test Run 2
    │   └── test-execution.log
    └── 2026-01-27_18-00-15/       ← Test Run 3
        └── test-execution.log
```

## Log File Format

### File Name
- **Main Log:** `test-execution.log`
- **Format:** Plain text with timestamps
- **Encoding:** UTF-8

### Timestamp Format
- **Folder:** `yyyy-MM-dd_HH-mm-ss` (e.g., `2026-01-27_15-30-45`)
- **Log Entry:** `yyyy-MM-dd HH:mm:ss.SSS` (e.g., `2026-01-27 15:30:45.123`)

## Log Levels

| Level | Icon | Purpose | Example |
|-------|------|---------|---------|
| **INFO** | ℹ️ | General information | Test started, configuration loaded |
| **SUCCESS** | ✅ | Successful operations | API call succeeded |
| **WARNING** | ⚠️ | Non-critical issues | Slow response time |
| **ERROR** | ❌ | Failures | API call failed |
| **REQUEST** | 🔹 | API requests | GET /users - Status: 200 |
| **RESPONSE** | 🔸 | API responses | Response time: 250ms |
| **GROUP_START** | 📂 | Group begins | Read Operations started |
| **GROUP_END** | 📁 | Group completes | Read Operations completed |

## Log Content

### 1. Test Header
```
================================================================================
                    GATLING PERFORMANCE TEST EXECUTION LOG
================================================================================
Test Started: 2026-01-27 15:30:45
Log Folder: test-logs/2026-01-27_15-30-45
================================================================================
```

### 2. Scenario Logs
```
================================================================================
🚀 SCENARIO START: User Management Scenario
👤 User: John Doe
⏰ Time: 15:30:45
================================================================================
```

### 3. Group Logs
```
[2026-01-27 15:30:46.123] [GROUP_START] 📂 Group Started: Read Operations
[2026-01-27 15:30:52.456] [GROUP_END] 📁 Group Completed: Read Operations
```

### 4. Request Logs
```
[2026-01-27 15:30:47.789] [REQUEST] API Request: GET /users - Status: 200
[2026-01-27 15:30:47.890] [SUCCESS] GET /users - Retrieved users successfully
```

### 5. Test Footer
```
================================================================================
Test Completed: 2026-01-27 15:40:45
================================================================================
```

## Using the Logger

### In Test Code

The `TestLogger` class provides these methods:

```java
// Basic logging
TestLogger.info("Information message");
TestLogger.success("Success message");
TestLogger.warning("Warning message");
TestLogger.error("Error message");

// API logging
TestLogger.logRequest("GET", "/users", "200");
TestLogger.logResponse("/users", "250", "200");

// Scenario logging
TestLogger.logScenarioStart("Scenario Name", "User Name");
TestLogger.logScenarioEnd("Scenario Name", "User Name");

// Group logging
TestLogger.logGroupStart("Group Name");
TestLogger.logGroupEnd("Group Name");

// Create separate log file
TestLogger.createSeparateLog("custom.log", "Custom content");
```

### Automatic Features

The framework automatically:
- ✅ Creates timestamped folders
- ✅ Initializes logger at test start
- ✅ Logs every API request/response
- ✅ Logs scenario start/end
- ✅ Logs group start/end
- ✅ Closes logger at test end
- ✅ Displays log location in console

## Accessing Logs

### Windows
```bash
# Open logs folder
explorer test-logs

# Open latest log folder
cd test-logs
dir /o:-d
cd <latest-folder>
notepad test-execution.log
```

### Linux/Mac
```bash
# Open logs folder
open test-logs

# View latest log
cd test-logs
ls -lt | head -2
cd <latest-folder>
cat test-execution.log
```

### PowerShell
```powershell
# Open latest log
$latest = Get-ChildItem test-logs -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
notepad "$($latest.FullName)\test-execution.log"
```

## Log Analysis

### Search for Errors
```bash
# Windows
findstr /i "ERROR" test-logs\2026-01-27_15-30-45\test-execution.log

# Linux/Mac
grep -i "ERROR" test-logs/2026-01-27_15-30-45/test-execution.log
```

### Count Requests
```bash
# Windows
find /c "REQUEST" test-logs\2026-01-27_15-30-45\test-execution.log

# Linux/Mac
grep -c "REQUEST" test-logs/2026-01-27_15-30-45/test-execution.log
```

### Filter by Log Level
```bash
# Windows - Show only SUCCESS logs
findstr "SUCCESS" test-logs\2026-01-27_15-30-45\test-execution.log

# Linux/Mac
grep "SUCCESS" test-logs/2026-01-27_15-30-45/test-execution.log
```

## Integration with CI/CD

### Archive Logs
```bash
# Zip logs for archival
tar -czf test-logs-2026-01-27.tar.gz test-logs/2026-01-27*
```

### Upload to Artifact Storage
```yaml
# GitHub Actions example
- name: Upload test logs
  uses: actions/upload-artifact@v3
  with:
    name: test-logs
    path: test-logs/
```

### Parse Logs for Metrics
```bash
# Extract response times
grep "Response time:" test-logs/*/test-execution.log > response-times.txt

# Count failures
grep -c "ERROR" test-logs/*/test-execution.log
```

## Best Practices

### ✅ Do's
- Keep logs for historical analysis
- Archive old logs (>30 days)
- Use log levels appropriately
- Include context in log messages
- Review logs after each test run

### ❌ Don'ts
- Don't log sensitive data (passwords, tokens)
- Don't create excessive separate log files
- Don't ignore warning messages
- Don't delete logs immediately after tests

## Troubleshooting

### Issue: Log folder not created
**Solution:** Check write permissions in project directory

### Issue: Logs not visible in folder
**Solution:** 
```bash
# Refresh folder view
# Or check: TestLogger.getTestRunFolder()
```

### Issue: Log file locked
**Solution:** Close any programs viewing the log file

### Issue: Logs taking too much space
**Solution:**
```bash
# Clean logs older than 30 days
find test-logs -type d -mtime +30 -exec rm -rf {} +
```

## Advanced Usage

### Custom Log Files

Create separate logs for specific purposes:

```java
// In your test code
StringBuilder summary = new StringBuilder();
summary.append("Test Summary\n");
summary.append("Total Users: 100\n");
summary.append("Success Rate: 98.5%\n");

TestLogger.createSeparateLog("test-summary.txt", summary.toString());
```

### Log Rotation

For long-running tests, implement log rotation:

```java
// Example: Create new log file every hour
// This would require extending TestLogger class
```

## Sample Complete Log

```
================================================================================
                    GATLING PERFORMANCE TEST EXECUTION LOG
================================================================================
Test Started: 2026-01-27 15:30:45
Log Folder: test-logs/2026-01-27_15-30-45
================================================================================

[2026-01-27 15:30:45.100] [INFO] Gatling Performance Test Starting...
[2026-01-27 15:30:45.105] [INFO] Duration: 10 minutes | Users: 2 per second
[2026-01-27 15:30:45.110] [INFO] Assertions configured successfully

================================================================================
🚀 SCENARIO START: User Management Scenario
👤 User: John Doe
⏰ Time: 15:30:45
================================================================================

[2026-01-27 15:30:46.200] [GROUP_START] 📂 Group Started: Read Operations
[2026-01-27 15:30:47.123] [REQUEST] API Request: GET /users - Status: 200
[2026-01-27 15:30:47.234] [SUCCESS] GET /users - Retrieved users successfully
[2026-01-27 15:30:49.345] [REQUEST] API Request: GET /users/1 - Status: 200
[2026-01-27 15:30:49.456] [SUCCESS] GET /users/1 - Retrieved user details
[2026-01-27 15:30:50.567] [GROUP_END] 📁 Group Completed: Read Operations

[2026-01-27 15:30:51.678] [GROUP_START] 📂 Group Started: Write Operations
[2026-01-27 15:30:52.789] [REQUEST] API Request: POST /users/add - Status: 200
[2026-01-27 15:30:52.890] [SUCCESS] POST /users/add - Created user: John
[2026-01-27 15:30:54.901] [REQUEST] API Request: PUT /users/1 - Status: 200
[2026-01-27 15:30:55.012] [SUCCESS] PUT /users/1 - User updated successfully
[2026-01-27 15:30:56.123] [GROUP_END] 📁 Group Completed: Write Operations

================================================================================
✅ SCENARIO END: User Management Scenario
👤 User: John Doe
⏰ Time: 15:31:15
================================================================================

[2026-01-27 15:40:45.000] [INFO] Test execution completed

================================================================================
Test Completed: 2026-01-27 15:40:45
================================================================================
```

## Support

For issues with logging:
1. Check console output for log folder location
2. Verify write permissions
3. Ensure TestLogger.initialize() is called
4. Check TestLogger.close() is called at end

## Related Files

- `TestLogger.java` - Logger implementation
- `test-execution.log` - Main log file
- `target/gatling/` - Gatling HTML reports (separate from custom logs)
